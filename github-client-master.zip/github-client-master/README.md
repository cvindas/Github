# Gihtub Client
A simple github client web applcation using OOP javascript and the Github API

# Screenshot
![](docs/screenshot.png)
